gcc -rdynamic -o  trace trace.c
./trace   